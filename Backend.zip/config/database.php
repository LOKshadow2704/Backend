<?php
if (!class_exists('DatabaseConfig')) {
    class DatabaseConfig {
        public static $host = 'localhost';
        public static $dbname = 'goatgym';
        public static $username = 'root';
        public static $password = '';
    }
}